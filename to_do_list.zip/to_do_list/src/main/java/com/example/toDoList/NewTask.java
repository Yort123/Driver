package com.example.toDoList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import org.controlsfx.control.spreadsheet.SpreadsheetCellType;

import java.time.LocalDate;


public class NewTask {
    private String task;
    private String date;
    private String combo;
    NewTask(String task, LocalDate date){

        this.task = task;
        this.date = String.valueOf(date);
        this.combo = "Task:  " + task + "  Date:  " + date;
    }

    public String getTask(){
        return this.task;
    }
    public String getCombo(){
        return this.combo;
    }
    public String getDate(){
        return this.date;
    }

    public String toString(){
        return String.format(this.task, ", ", this.date);
    }
}
