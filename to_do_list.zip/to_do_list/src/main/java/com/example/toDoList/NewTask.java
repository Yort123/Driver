package com.example.toDoList;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;


public class NewTask {
    private String task;
    private ObjectProperty priority;
    NewTask(StringProperty task, ObjectProperty priority){

        this.task = String.valueOf(task);
        this.priority = priority;
    }

//    public void setTask(String task){
//        this.task = task;
//    }
//    public void setPriority(String priority){
//        this.priority = priority;
//    }

    public String getTask(){
        return this.task;
    }
    public ObjectProperty getPriority(){
        return this.priority;
    }

}
