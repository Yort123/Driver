package com.example.toDoList;

import java.time.LocalDate;

public class NewTask {
    private final String task;
    private final LocalDate date;
    private final String combo;
    NewTask(String task, LocalDate date){

        this.task = task;
        this.date = date;

        // combo variable what is to be displayed in the table
        this.combo = "Task:  " + task + "  Date:  " + String.valueOf(date);
    }

    public String getTask(){
        return this.task;
    }
    public LocalDate getDate(){ return this.date; }
    public String getCombo(){
        return this.combo;
    }
}
