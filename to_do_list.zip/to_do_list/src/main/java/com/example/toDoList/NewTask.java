package com.example.toDoList;

import java.time.LocalDate;

public class NewTask {
    private final String task;
    private final String date;
    private final String combo;
    NewTask(String task, LocalDate date){

        this.task = task;
        this.date = String.valueOf(date);

        // combo variable what is to be displayed in the table
        this.combo = "Task:  " + task + "  Date:  " + date;
    }

    public String getTask(){
        return this.task;
    }
    public String getDate(){
        return this.date;
    }
    public String getCombo(){
        return this.combo;
    }
}
