package com.example.toDoList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.util.Callback;


public class ToDoController {

    @FXML
    public TableView<NewTask> tableView;
    @FXML
    public DatePicker date;
    private int toDoCount;
    private int inProgressCount;
    private int completedCount;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<NewTask, String> completed;

    @FXML
    private TableColumn<NewTask, String> inProgress;

    @FXML
    private TextField taskName;

    @FXML
    private TableColumn<NewTask, String> toDo;

    @FXML
    public void addButton(){
        ObservableList<NewTask> newTask = task();
        System.out.println(newTask);
        tableView.setItems(newTask);
//        toDo.setUserData();
    }

    public ObservableList<NewTask> task() {
        return FXCollections.observableArrayList(new NewTask(taskName.textProperty(), date.valueProperty()));
    }
}