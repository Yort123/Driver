package com.example.toDoList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;


public class ToDoController implements Initializable {

    @FXML
    public TableView<NewTask> tableView;
    @FXML
    public DatePicker date;
    @FXML
    public TableColumn<NewTask, String> toDoDate;
    @FXML
    public TableColumn<NewTask, String> toDoTask;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<NewTask, String> completed;

    @FXML
    private TableColumn<NewTask, String> inProgress;

    @FXML
    private TextField taskName;

    @FXML
    private TableColumn<NewTask, String> toDo;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        toDoTask.setCellValueFactory(new PropertyValueFactory<NewTask, String>("task"));
        toDoDate.setCellValueFactory(new PropertyValueFactory<NewTask, String>("date"));
        completed.setCellValueFactory(new PropertyValueFactory<NewTask, String>("newTask"));

    }

    @FXML
    public void addButton(){
        NewTask test = new NewTask(taskName.getText(), date.getValue());

        tableView.getItems().add(test);
        taskName.clear();
    }
}